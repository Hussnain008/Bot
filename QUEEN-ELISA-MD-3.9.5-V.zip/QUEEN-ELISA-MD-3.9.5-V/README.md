
<p align="center"> 
<u>♥️ ᴀɴ ᴡʜᴀᴛsᴀᴘᴘ ᴜsᴇʀ ʙᴏᴛ ʙʏ ᴍʀ ɴɪᴍᴀ ♥️</u>
</p>
<p align="center">
<img src="https://i.ibb.co/nPYVtwV/queen-elisa-new-logo-600-600.jpg" width="300" height="300"/>
</p>
<p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=d1fa02&center=true&vCenter=true&multiline=false&lines=QUEEN+ELISA+WHATSAPP+BOT" alt="">
</p>
<p align="center">
<a href="#"><img title="Creator" src="https://img.shields.io/badge/Creator-Mrnima-red.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/darkmakerofc?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/AlipBot?color=green&style=flat-square"></a>
<a href="https://github.com/DarkMakerofc/Queen-Elisa-Md-V2/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/darkmakerofc/Queen-Elisa-MD-V2?color=white&style=flat-square"></a>
<a href="https://github.com/DarkMakerofc/Queen-Elisa-Md-V2/network/members"><img title="Forks" src="https://img.shields.io/github/forks/darkmakerofc/Queen-Elisa-MD-V2?color=yellow&style=flat-square"></a>
<a href="https://github.com/DarkMakerofc/Queen-Elisa-Md-V2/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/darkmakerofc/Queen-Elisa-MD-V2?label=Watchers&color=red&style=flat-square"></a>
<a href="https://github.com/DarkMakerofc/Queen-Elisa-Md-V2/"><img title="Size" src="https://img.shields.io/github/repo-size/AlipBot/Api-Alpis?style=flat-square&color=darkred"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/DarkMakerofc/Queen-Elisa-Md-V2/%2Fhit-counter&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2304FF00&title=hits&edge_flat=false"/></a>
<a href="https://github.com/DarkMakerofc/Queen-Elisa-Md-V2/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained-No-red.svg"></a>&nbsp;&nbsp;
</p>

# 

### Please Give One Star ✨ & [follow for me notify my updates 💗](https://github.com/DarkMakerofc)
<b>Version -> 3.9.6</b>
# 
Queen elisa whatsapp bot is,

      Queen elisa whatsapp bot is an easy to use whatsapp robot.   |  Queen elisa whatsapp bot යනු ඔබට පහසුවෙන් බාවිතකර හැකි whatsapp robo වරයෙකි.

# 
* 𝗙𝗢𝗥𝗞 𝗡𝗢𝗪

<p align="left">
<a href="https://github.com/DarkMakerofc/Queen-Elisa-MD-V2/fork"><img align="center" src="https://telegra.ph/file/3514997e86c4bb12d8f67.png" alt="Fork and deploy" height="35" width="155" /></a>

# 

* [`𝗦𝗖𝗔𝗡 𝗤𝗥 𝗖𝗢𝗗𝗘`](https://replit.com/@MRNima/QUEEN-ELISA-MULTIAUTH-QR-SCANER)

      ℹ️ if there any error please infrom it support group.  | මෙහිදී යම් ගැටලුවක් ඇති උවහොත් සහය සමූහය වෙත සම්බන්ධ වන්න.
# 

<details>
<summary>𝗖𝗟𝗜𝗖𝗞 𝗧𝗢 𝗗𝗘𝗣𝗟𝗢𝗬</summary>


[`Deploy on Railway`](https://railway.app?referralCode=jDDNQq)

[`Deploy on Koyeb`](https://app.koyeb.com/)

[`Deploy on Mogenius`](https://studio.mogenius.com/)

[`Deploy on heroku`](https://heroku.com/deploy?template=https://github.com/DarkMakerofc/Queen-Elisa-MD-V2)

[`Deploy on Replit`](https://replit.com)

[`Deploy on Uffizzi`](https://www.uffizzi.com/)
</details>

## [`WATCH YOUTUBE VIDEOS`](youtube.com/MRNIMAOFC)
 
  ##* [How To setup Github 1st step](https://youtu.be/DEpSpJRg4CA)
  
 * Deploy on Heroku Video ⇓
 <p align="left">
<a href="https://youtu.be/IIl6etHMyoA"><img align="center" src="https://telegra.ph/file/30a48f9e9879189d2ef6d.jpg" alt="DEPLOY" height="110" width="200" /></a>
   
* Deploy on Railway Video ⇓
 <p align="left">
<a href="https://youtu.be/j91TKKIXaMg"><img align="center" src="https://telegra.ph/file/517fafc4228129ff18510.jpg" alt="DEPLOY" height="110" width="200" /></a>
   
* Deploy on Replit Video ⇓
 <p align="left">
<a href="[https://youtube.com/mrnimaofc](https://youtu.be/j91TKKIXaMg)"><img align="center" src="https://telegra.ph/file/909f2519b1dc65a338b29.jpg" alt="DEPLOY" height="110" width="200" /></a>
   
   
   
# 
#
+ DEPLOY STEPS
# 
1. Fork This Repository 
2. Update [settings.js]()
3. Uplode creds.json file to sessions folder
4. Make acount on your host
5. Connect Your Repository to your web host site
6. [Watch Videos](http://youtube.com/mrnimaofc)
# 
# 
### [ DEPLY ON TERMUX ]
 ```   
apt update
apt upgrade
pkg update && pkg upgrade
pkg install bash
pkg install libwebp
pkg install git -y
pkg install nodejs -y 
pkg install ffmpeg -y 
pkg install wget
pkg install imagemagick -y
git clone https://github.com/DarkMakerofc/Queen-Elisa-Md-V2
cd Queen-Elisa-Md-V2
npm install
npm start
```
<details>
<summary>✅ New Updates</summary>

• Fix Youtube video and song not download error. 


<p>
</details>
<details>
<summary>ℹ️ How To Update </summary>
<p>
</details>
<details>
<summary>🌐 Support For Deploy </summary>
<p>
</details>
THANAKS FOR USNING QUEEN ELISA 💃💖

* [🧑‍💻 Join Queen Elisa Support Group 🧑‍💻](https://t.me/+Fc2vyKYBjFk3ZWZl)

* [🦄 Join Public Group 🦄](https://chat.whatsapp.com/BbIpvkRD4qP6xKckb8cpT0)

     
       ⚠️ We are not responsible for any inconvenience caused by your mistakes!   | ඔබගේ අත්වැරදීම් නිසා සිදුවන අපහසුතාවයන් සඳහා අප වගකිවයනු නොලැබේ !

  
  #### ```TOTAL PROFILE VIEWS 🧚```
![Visitor Count](https://profile-counter.glitch.me/DarkMakerofc/count.svg)

<h1>💗</h1> 
<b>Thanks For</b> -

 [thashi 💖]() for Voice ,[slrealtech](https://youtube.com/slrealtech) , [darkalpha](http://github.com/darkalphaxteam) and [isuru]() thanks for helps 💖

 ## [ WHATSAPP GROUPS ](https://github.com/DarkMakerofc/groups#README.md)
